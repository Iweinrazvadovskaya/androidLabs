package by.bstu.razvod.lab4.extendes;

import by.bstu.razvod.lab4.MainViewPresentation;

public interface LongClickListener {
    void onLongClick(MainViewPresentation mainViewPresentation);
}
