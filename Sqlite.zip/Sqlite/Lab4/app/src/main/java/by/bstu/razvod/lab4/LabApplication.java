package by.bstu.razvod.lab4;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class LabApplication extends Application {
}
