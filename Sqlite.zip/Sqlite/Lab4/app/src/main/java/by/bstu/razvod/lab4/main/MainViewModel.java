package by.bstu.razvod.lab4.main;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.hilt.lifecycle.ViewModelInject;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

import by.bstu.razvod.lab4.DataSqlRepository;
import by.bstu.razvod.lab4.MainViewPresentation;
import by.bstu.razvod.lab4.model.ContactModel;
import io.reactivex.rxjava3.core.Completable;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.subjects.BehaviorSubject;

public class MainViewModel extends AndroidViewModel {

    private DataSqlRepository dataRepository;

    private BehaviorSubject<ArrayList<ContactModel>> selectedSubject = BehaviorSubject.createDefault(new ArrayList<ContactModel>());
    public MutableLiveData<Boolean> showFavorite = new MutableLiveData<>();

    @ViewModelInject
    public MainViewModel(@NonNull Application application, DataSqlRepository dataRepository) {
        super(application);
        this.dataRepository = dataRepository;
        compositeDisposable.add(Observable.combineLatest(dataRepository.contactLiveData, selectedSubject, (contactModels, selected) -> {
            return contactModels.stream().map(item -> new MainViewPresentation(item, selected.contains(item))).collect(Collectors.toCollection(ArrayList::new));
        }).debounce(50, TimeUnit.MILLISECONDS)
                .subscribe(list -> {
                    contactLiveData.postValue(list);
                }));
    }

    public void updateDataSet(ContactModel newContactModel) {
        ArrayList<ContactModel> list = selectedSubject.getValue();
        List<ContactModel> newList = list.stream().map(new Function<ContactModel, ContactModel>() {

            @Override
            public ContactModel apply(ContactModel contactModel) {
                if (newContactModel.getId() == contactModel.getId()) {
                    return newContactModel;
                }
                else {
                    return contactModel;
                }
            }

        }).collect(Collectors.toList());
        selectedSubject.onNext(new ArrayList<>(newList));
    }

    public void changeSelection(MainViewPresentation mainViewPresentation) {
        ArrayList<ContactModel> list = selectedSubject.getValue();
        if (list.contains(mainViewPresentation.getModel())) {
            list.remove(mainViewPresentation.getModel());
        } else {
            list.add(mainViewPresentation.getModel());
        }
        selectedSubject.onNext(list);
    }

    public MutableLiveData<List<MainViewPresentation>> contactLiveData = new MutableLiveData<>();

    private CompositeDisposable compositeDisposable = new CompositeDisposable();

    @Override
    protected void onCleared() {
        super.onCleared();
        compositeDisposable.clear();
    }


    public void addNewContact(ContactModel contactModel) {
        dataRepository.addNewContact(contactModel);
    }

    public void findContact(String name) {
        dataRepository.findElement(name);
    }

    public Completable editContact(ContactModel contactModel) {
        return dataRepository.updateContact(contactModel);
    }

    public Completable makeFavorite(MainViewPresentation mainViewPresentation) {
        ContactModel contactModel = mainViewPresentation.getModel();
        contactModel.setFavoriteContact();
        return dataRepository.updateContact(contactModel);
    }

    public void showFavorite() {
        showFavorite.postValue(dataRepository.selectFavorite());
    }

    public ContactModel getContact(long id){
        return dataRepository.getContact(id);
    }

    public void deleteContact(MainViewPresentation mainViewPresentation) {
        dataRepository.removeContact(mainViewPresentation.getModel());

        if (selectedSubject.getValue().contains(mainViewPresentation.getModel())) {
            ArrayList<ContactModel> list = selectedSubject.getValue();
            list.remove(mainViewPresentation.getModel());
            selectedSubject.onNext(list);
        }
    }

}
