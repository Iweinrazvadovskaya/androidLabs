package by.bstu.razvod.lab4.extendes;

import by.bstu.razvod.lab4.MainViewPresentation;

public interface ClickListener {
    void onClick(MainViewPresentation presentation);
}
